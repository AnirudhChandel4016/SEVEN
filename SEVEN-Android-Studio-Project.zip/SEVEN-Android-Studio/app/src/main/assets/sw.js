const CACHE='seven-shell-v3';
const CORE=['/','/index.html','/styles.css','/app.js','/cloud.js','/syllabus-seed.json','/syllabus-verification.json','/manifest.webmanifest','/icon.svg','/icon-192.png','/icon-512.png'];
self.addEventListener('install',event=>{event.waitUntil((async()=>{const cache=await caches.open(CACHE);await Promise.all(CORE.map(async url=>{try{await cache.add(url)}catch(error){console.warn('SEVEN precache skipped:',url)}}));await self.skipWaiting()})())});
self.addEventListener('activate',event=>{event.waitUntil((async()=>{const keys=await caches.keys();await Promise.all(keys.filter(key=>key.startsWith('seven-shell-')&&key!==CACHE).map(key=>caches.delete(key)));await self.clients.claim()})())});
self.addEventListener('message',event=>{if(event.data==='SKIP_WAITING')self.skipWaiting()});
self.addEventListener('fetch',event=>{const request=event.request;if(request.method!=='GET')return;const url=new URL(request.url);if(url.origin!==self.location.origin)return;
 if(request.mode==='navigate'){event.respondWith((async()=>{try{const response=await fetch(request);const cache=await caches.open(CACHE);cache.put('/index.html',response.clone());return response}catch(error){return (await caches.match('/index.html'))||Response.error()}})());return;}
 event.respondWith((async()=>{const cached=await caches.match(request);const network=fetch(request).then(async response=>{if(response&&response.ok){const cache=await caches.open(CACHE);cache.put(request,response.clone())}return response}).catch(()=>null);return cached||await network||Response.error()})());
});
