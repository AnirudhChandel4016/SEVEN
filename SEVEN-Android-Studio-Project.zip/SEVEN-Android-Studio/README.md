# SEVEN — Android Studio project

This is the Android WebView wrapper for the SEVEN CBSE Class 10 study app. It packages the existing offline-first web app inside a native Android launcher app. The project is source code, **not a prebuilt APK**.

## Build an APK (recommended: GitHub Actions)
1. Create a GitHub repository and upload this entire folder.
2. Open the repository's **Actions** tab.
3. Select **Build SEVEN APK** and choose **Run workflow** (or push to `main`).
4. When the workflow finishes, open its run and download the `SEVEN-debug-apk` artifact.
5. Extract the artifact; it contains `app-debug.apk`. Transfer it to your Android phone and install it. Android may ask you to allow installs from that file manager/browser.

The workflow installs Android SDK 35 and Gradle 8.9, then runs `assembleDebug`. A debug APK is suitable for personal testing; publishing to Google Play requires a signed release build and Play Console setup.

## Build locally
Install Android Studio, JDK 17, Android SDK Platform 35 and Build Tools 35.0.0. Install Gradle 8.9, open a terminal in this folder and run:

```bash
gradle --no-daemon assembleDebug
```

Output: `app/build/outputs/apk/debug/app-debug.apk`.

## App behavior and honest limitations
- The app uses Android System WebView with locally bundled HTML, CSS, JavaScript and syllabus seed data. Core study screens and local browser storage work without hosting.
- External website links open in the phone's browser. Firebase imports and cloud features require your own Firebase configuration and network access.
- Firebase Authentication/Firestore, Cloud Run uploads and AI backend are **not configured** by this project. No credentials are included.
- File selection is enabled for the app's upload control. Cloud upload still requires the backend setup described in `WEB-APP-README.md`.
- Progress is stored in the app's WebView local storage. Uninstalling the app or clearing its storage can erase local progress; export a backup from Settings first.
- Test on your Android version before relying on it for important study records.

## Package identity
- App name: SEVEN
- Application ID: `com.seven.studycommandcentre`
- Minimum Android: 6.0 (API 23)
- Target SDK: 35
