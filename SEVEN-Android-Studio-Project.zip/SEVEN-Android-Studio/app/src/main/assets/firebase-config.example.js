// Copy to firebase-config.js and fill from Firebase Console > Project settings > Web app.
export const firebaseConfig = { apiKey:"YOUR_FIREBASE_WEB_API_KEY", authDomain:"YOUR_PROJECT.firebaseapp.com", projectId:"YOUR_PROJECT_ID", appId:"YOUR_FIREBASE_WEB_APP_ID" };
// This web-app config is public client config. Never put service-account keys here.
