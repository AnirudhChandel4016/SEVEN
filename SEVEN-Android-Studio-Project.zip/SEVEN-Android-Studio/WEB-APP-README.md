# SEVEN — CBSE Class 10 Study Command Centre v3
Includes: (1) premium Android-first responsive interface with thumb-friendly bottom navigation, safe-area support and accessible touch targets, (2) installable PWA manifest with Android launcher shortcuts and 192/512 maskable icons, (3) versioned offline app-shell caching, and (4) the existing study suite plus Firebase + Google Cloud integration scaffold.

## Honest feature status
Local demo mode stores progress in this browser. Firebase Authentication + Firestore sync activate only after creating `public/firebase-config.js` from the example and enabling Email/Password Auth + Firestore. GCS uploads require deployed Cloud Run, private bucket, CORS and IAM configuration. AI assistant uses ChatGPT handoff; no AI key or in-app AI is configured. This package has not been deployed to your Google Cloud project or physically tested on an Android handset. Validate the install prompt, safe-area layout, bottom navigation, offline reopen and update lifecycle on your target Android/Chrome version before relying on it.

## Run locally
Node.js 20+: `npx serve public`. Use localhost or HTTPS for service workers.

## Android install and PWA experience
Deploy `public/` to Firebase Hosting over HTTPS (or another HTTPS host), open in Chrome Android, then use the in-app Install prompt or Chrome menu → Install app / Add to Home screen. The manifest includes portrait-first standalone display, Android launcher icons and shortcuts for Planner, Practice and Syllabus. On narrow screens, the app uses a persistent five-item bottom navigation bar; the full feature menu remains in the slide-out drawer. The service worker precaches the app shell and uses network-first navigation with cached fallback. Core screens can reopen offline after the first successful load; external links, Firebase sync, AI handoff and remote uploads still require connectivity. User progress remains in browser local storage unless Firebase is configured.

## Firebase
Create Firebase project/Web App; enable Authentication > Email/Password and Firestore. Copy `public/firebase-config.example.js` to `public/firebase-config.js`, fill web config, then deploy `firestore.rules`. Data path is `users/{uid}/app/state`; rules restrict records to the authenticated UID.

## Google Cloud Storage + Cloud Run
Create a private GCS bucket with uniform bucket-level access. Give Cloud Run service account least-privilege object permissions. Deploy from backend:
`npm install`
`gcloud run deploy seven-api --source . --region asia-south1 --allow-unauthenticated --set-env-vars GCS_BUCKET=YOUR_PRIVATE_BUCKET,ALLOWED_ORIGIN=https://YOUR_HOSTING_DOMAIN`
Protected routes verify Firebase ID tokens. Configure bucket CORS only for your hosting origin and PUT with Content-Type. Signed URLs expire after five minutes. Never make the bucket public or place service-account/model keys in frontend code; store secrets in Secret Manager.

## Hosting
Install Firebase CLI, login, copy `.firebaserc.example` to `.firebaserc`, set project ID, then `firebase deploy --only hosting,firestore:rules`. Hosting rewrite expects Cloud Run service `seven-api` in `asia-south1`.

## Official syllabus and PYQs
Official 2026–27 curriculum: https://cbseacademic.nic.in/curriculum_2027.html. Open initial pages and each subject PDF before treating individual chapters as compulsory. The chapter seed is a planning list, not a verified exhaustive syllabus.
Sample papers: https://cbseacademic.nic.in/SQP_CLASSX_2026-27.html
PYQs: https://www.cbse.gov.in/cbsenew/question-paper.html
Marking schemes: https://www.cbse.gov.in/cbsenew/marking-scheme.html

## v3 UI/PWA upgrade
- Refined mobile hierarchy, spacing, card surfaces, touch targets, safe-area padding and reduced-motion support.
- Added fixed mobile quick navigation for Home, Planner, Syllabus, Practice and Revision; the sidebar retains all modules.
- Added install prompt handling, iOS/Android app metadata, portrait-first PWA settings and launcher shortcuts.
- Added PNG 192×192 and 512×512 icons for install surfaces.
- Reworked service-worker caching with versioned cache cleanup, app-shell precache, network-first navigation fallback and runtime asset caching.
- Added offline/online status text in the header.

## Limitations and tests
Cloud sync is document-level last-writer-wins; production multi-device concurrency needs per-record revisions/conflict resolution. Test Android/desktop layout, PWA install, offline shell, export/import, Firebase auth, two-device sync, cross-user isolation, signed uploads/downloads, bucket privacy, CORS and URL expiry before storing private data. The seven-day sprint is first-pass coverage, not a promise of mastery or marks. Protect sleep, meals and breaks. The PYQ Vault links to official CBSE pages; original practice is not labelled as official PYQ.
